let message: string | number = "Hello, Epps"

message = 100

// message = false   // gera erro -> "Type 'boolean' is not assignable to type 'string | number'"

console.log(message)